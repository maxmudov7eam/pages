import React, {useEffect, useState} from 'react'
import CurrencyRow from './CurrencyRow';
import '../sass/currency.scss'

const Main = () => {

    const [currencyOptions, setCurrencyOptions] = useState([]);
    console.log(currencyOptions);
    const [fromCurrency, setFromCurrency] = useState();
    const [toCurrency, setToCurrency] = useState();
    const [amount, setAmount] = useState(1);
    const [amountFromCurrency, setAmountFromCurrency] = useState(true);
    const [exchangeRate, setExchangeRate] = useState();
    const [froms, setFroms] = useState([]);
    const [tos, setTos] = useState([]);

    

    const URL = 'http://api.exchangeratesapi.io/v1/latest?access_key=c0605696fdb4a0242f65f17047506865&format=1';

    console.log(exchangeRate + "rates");

    let toAmount, fromAmount;

    if(amountFromCurrency) {
        fromAmount = amount;
        toAmount = amount * exchangeRate
    } else {
        toAmount = amount; 
        fromAmount = amount / exchangeRate;
    }

    useEffect(() => {
        fetch(URL)
            .then(res => res.json())
            .then(data => {
                const firstCurrency = Object.keys(data.rates)[0]
                console.log("dates" + data);
                setCurrencyOptions([data.base, ...Object.keys(data.rates)])
                setFromCurrency(data.base)
                setToCurrency(firstCurrency);
                setExchangeRate(data.rates[firstCurrency])
            })
    },[]);

    useEffect(() => {
        if(fromCurrency != null && toCurrency != null) {
            fetch(`${URL}?base=${fromCurrency}&symbols=${toCurrency}`)
            .then(res => res.json())
            .then(data => setExchangeRate(data.rates[toCurrency]))
        }
    }, [fromCurrency, toCurrency])


    const handleFromAmountChange = (e) => {
        setAmount(e.target.value);
        setAmountFromCurrency(true)
    }
    const handleToAmountChange = (e) => {
        setAmount(e.target.value);
        setAmountFromCurrency(false);
    }


    return (
        <>
        <div className="container mt-5">
            <div className="row flex-nowrap">
                <div className="col-4">
                    <h4 class>From</h4>
                    <CurrencyRow 
                        currencyOptions={currencyOptions}
                        selectedCurrency={fromCurrency}
                        onChangeCurrency={e => setFromCurrency(e.target.value)}
                        amount={fromAmount}
                        onChangeAmount={handleFromAmountChange}
                    />
                    <button className="btn btn-success myBtn1">+</button>
                </div>
                    <div className="col-4">
                        <h4 class>To</h4>
                        <CurrencyRow 
                            currencyOptions={currencyOptions}
                            selectedCurrency={toCurrency}
                            onChangeCurrency={e => setToCurrency(e.target.value)}
                            amount={toAmount}
                            onChangeAmount={handleToAmountChange}
                        />
                        <button className="btn btn-success">+</button>
                </div>
            </div>
        </div>
        </>
    )
}

export default Main;

