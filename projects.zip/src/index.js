import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';
// import Trello from './lesson/AppTwo';
import Korona from './lesson5/Korona'

import 'bootstrap/dist/css/bootstrap.css';
import './lesson/AppTwo.css';
import 'react-toastify/dist/ReactToastify.css';


ReactDOM.render(<Korona/>, document.getElementById('root'))

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

