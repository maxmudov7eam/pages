import React from 'react';

class Toggle extends React.Component {
    render() {
        return (
            <>
                <button className="btn btn-outline-success" type='button'>Click me!</button>
                
                <p className='text'>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur saepe tenetur vel similique eius, adipisci officiis eveniet quisquam, rem, deleniti dolorem. Deleniti et velit consequatur, magni numquam qui hic saepe!
                </p>
            </>
        );
    };
};

export default Toggle;