
import Maps from './homework/Maps';
import Todo from './homework/Todo';
import Toggle from './homework/Toggle';

function App() {
  return (
    <div className="App">
        {/* <Maps /> */}
        <div className="row">
            <div className="col-12">
                <Project />
            </div>
        </div>
        <div className="row">
            <div className="col-12">
                {/* <Toggle/> */}
            </div>
        </div>
    </div>
  );
}

export default App;
